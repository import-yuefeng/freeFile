# API版本说明
    
  * 使用`yum install redis`

  * 使用`yum install mongodb`

  * 可选启动redis及mongodb, 需要自行配置项目中的`setting.conf` 文件
* 不启动相关数据库的话, 部分功能无法使用!
