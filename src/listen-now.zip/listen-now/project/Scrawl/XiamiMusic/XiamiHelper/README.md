## xiami_encrypt
xiami_encrypt是虾米音乐加密的方式
(应该说是解密方式...命名失误)

